window.addEventListener('load', () => {
  const titleElement = document.querySelector('[data-testid="hero-title-block__title"]') || document.querySelector('h1.headline-1');
  const yearElement = document.querySelector('a[href*="/films/year/"]') || document.querySelector('small.number');

  if (!titleElement || !yearElement) {
    console.warn('Title or year not found ...');
    return;
  }

  const title = titleElement.innerText.trim().replace(/\s+/g, '+');
  const year = yearElement.innerText.trim().replace(/[()]/g, '');

  const query = `${title}+${year}`;
  const targetUrl = `https://www.yggtorrent.top/engine/search?name=${query}&do=search`;

  const button = document.createElement('button');
  button.innerText = '🔎 Check this title on Ygg ! ';
  button.style.cssText = `
    position: fixed;
    top: 100px; 
    right: 10px; 
    padding: 10px 15px;
    background-color: rgb(67, 180, 171);
    color: white;
    border: dotted;
    border-radius: 3px;
    cursor: pointer;
    z-index: 1000;
  `;

  button.onclick = () => {
    window.open(targetUrl, '_blank');
  };

  document.body.appendChild(button);
});